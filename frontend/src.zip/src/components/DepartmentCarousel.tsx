'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import DepartmentCard from './DepartmentCard';
import type { Department } from '@/lib/types';

interface DepartmentCarouselProps {
  departments: Department[];
  colors: Record<string, string>;
  labels: Record<string, string>;
}

export default function DepartmentCarousel({ 
  departments, 
  colors, 
  labels 
}: DepartmentCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isHovering, setIsHovering] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeft, setScrollLeft] = useState(0);
  const carouselRef = useRef<HTMLDivElement>(null);
  const autoScrollInterval = useRef<NodeJS.Timeout | null>(null);
  
  // Calculate visible items based on screen size
  const getVisibleItems = useCallback(() => {
    if (typeof window === 'undefined') return 4;
    if (window.innerWidth < 640) return 1;
    if (window.innerWidth < 768) return 2;
    if (window.innerWidth < 1024) return 3;
    return 4;
  }, []);

  const [visibleItems, setVisibleItems] = useState(4);
  const totalItems = departments.length;

  // Update visible items on resize
  useEffect(() => {
    const updateVisibleItems = () => {
      setVisibleItems(getVisibleItems());
    };
    
    updateVisibleItems();
    window.addEventListener('resize', updateVisibleItems);
    return () => window.removeEventListener('resize', updateVisibleItems);
  }, [getVisibleItems]);

  // Auto-scroll functionality
  useEffect(() => {
    if (!isHovering && !isDragging && totalItems > visibleItems) {
      autoScrollInterval.current = setInterval(() => {
        setCurrentIndex((prev) => {
          const nextIndex = prev + 1;
          return nextIndex >= totalItems ? 0 : nextIndex;
        });
      }, 3000);
    } else {
      if (autoScrollInterval.current) {
        clearInterval(autoScrollInterval.current);
        autoScrollInterval.current = null;
      }
    }

    return () => {
      if (autoScrollInterval.current) {
        clearInterval(autoScrollInterval.current);
        autoScrollInterval.current = null;
      }
    };
  }, [isHovering, isDragging, totalItems, visibleItems]);

  // Scroll to current index
  useEffect(() => {
    const container = carouselRef.current;
    if (!container) return;

    const cardWidth = container.querySelector('.carousel-item')?.clientWidth || 220;
    const gap = 16; // gap-4 = 16px
    const scrollPosition = currentIndex * (cardWidth + gap);
    
    container.scrollTo({
      left: scrollPosition,
      behavior: 'smooth'
    });
  }, [currentIndex]);

  // Check if we can scroll
  const canScrollLeft = currentIndex > 0;
  const canScrollRight = currentIndex < totalItems - visibleItems;

  // Handle manual scroll
  const scrollCarousel = (direction: 'left' | 'right') => {
    if (direction === 'left' && canScrollLeft) {
      setCurrentIndex(prev => prev - 1);
    } else if (direction === 'right' && canScrollRight) {
      setCurrentIndex(prev => prev + 1);
    }
  };

  // Handle drag scrolling
  const handleMouseDown = (e: React.MouseEvent) => {
    const container = carouselRef.current;
    if (container) {
      setIsDragging(true);
      setStartX(e.pageX - container.offsetLeft);
      setScrollLeft(container.scrollLeft);
      container.style.cursor = 'grabbing';
      container.style.userSelect = 'none';
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    const container = carouselRef.current;
    if (container) {
      e.preventDefault();
      const x = e.pageX - container.offsetLeft;
      const walk = (x - startX) * 1.5;
      container.scrollLeft = scrollLeft - walk;
    }
  };

  const handleMouseUp = () => {
    const container = carouselRef.current;
    if (container) {
      setIsDragging(false);
      container.style.cursor = 'grab';
      container.style.userSelect = 'auto';
      
      // Update current index based on scroll position
      const cardWidth = container.querySelector('.carousel-item')?.clientWidth || 220;
      const gap = 16;
      const newIndex = Math.round(container.scrollLeft / (cardWidth + gap));
      setCurrentIndex(Math.min(newIndex, totalItems - visibleItems));
    }
  };

  const handleMouseLeave = () => {
    setIsHovering(false);
    if (!isDragging) {
      const container = carouselRef.current;
      if (container) {
        container.style.cursor = 'grab';
        container.style.userSelect = 'auto';
      }
    }
  };

  // Touch support
  const handleTouchStart = (e: React.TouchEvent) => {
    const container = carouselRef.current;
    if (container) {
      const touch = e.touches[0];
      setStartX(touch.pageX - container.offsetLeft);
      setScrollLeft(container.scrollLeft);
      setIsDragging(true);
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging) return;
    const container = carouselRef.current;
    if (container) {
      const touch = e.touches[0];
      const x = touch.pageX - container.offsetLeft;
      const walk = (x - startX) * 1.5;
      container.scrollLeft = scrollLeft - walk;
    }
  };

  const handleTouchEnd = () => {
    const container = carouselRef.current;
    if (container) {
      setIsDragging(false);
      const cardWidth = container.querySelector('.carousel-item')?.clientWidth || 220;
      const gap = 16;
      const newIndex = Math.round(container.scrollLeft / (cardWidth + gap));
      setCurrentIndex(Math.min(newIndex, totalItems - visibleItems));
    }
  };

  if (departments.length === 0) {
    return null;
  }

  return (
    <div className="relative">
      <h2 className="text-2xl font-bold mb-4">Shop by</h2>
      
      <div 
        ref={carouselRef}
        className="flex overflow-x-auto gap-4 pb-2 scroll-smooth"
        style={{
          scrollbarWidth: 'none',
          msOverflowStyle: 'none',
          cursor: 'grab',
          WebkitOverflowScrolling: 'touch',
          overflowX: 'auto',
          overflowY: 'hidden',
          scrollBehavior: 'smooth'
        }}
        onMouseEnter={() => setIsHovering(true)}
        onMouseLeave={handleMouseLeave}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {departments.map((dept, index) => {
          const color = colors[dept.slug as keyof typeof colors] || "#9CA3AF";
          const label = labels[dept.slug as keyof typeof labels] || dept.name;
          
          return (
            <div 
              key={dept.slug}
              className="carousel-item flex-shrink-0 w-[200px] md:w-[220px] lg:w-[250px]"
            >
              <DepartmentCard
                department={dept}
                color={color}
                label={label}
              />
            </div>
          );
        })}
      </div>

      <style jsx>{`
        div::-webkit-scrollbar {
          display: none;
        }
      `}</style>

      {/* Navigation Buttons */}
      {totalItems > visibleItems && (
        <>
          <button
            onClick={() => scrollCarousel('left')}
            className={`
              absolute left-0 top-1/2 -translate-y-1/2 -translate-x-3 
              bg-white shadow-lg rounded-full p-2 hover:bg-gray-50 
              transition-all duration-200 hover:scale-110 z-10 
              hidden md:flex items-center justify-center
              ${canScrollLeft ? 'opacity-100' : 'opacity-0 pointer-events-none'}
            `}
            aria-label="Scroll left"
          >
            <svg className="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>

          <button
            onClick={() => scrollCarousel('right')}
            className={`
              absolute right-0 top-1/2 -translate-y-1/2 translate-x-3 
              bg-white shadow-lg rounded-full p-2 hover:bg-gray-50 
              transition-all duration-200 hover:scale-110 z-10 
              hidden md:flex items-center justify-center
              ${canScrollRight ? 'opacity-100' : 'opacity-0 pointer-events-none'}
            `}
            aria-label="Scroll right"
          >
            <svg className="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </>
      )}
    </div>
  );
}