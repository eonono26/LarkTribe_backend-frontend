"use client";

import { useState, useEffect, useRef } from "react";
import Image from "next/image";
import Link from "next/link";
import { Heart, ShoppingBag, Eye, Star, ImageOff, Plus, Check } from "lucide-react";
import { useCart } from "@/lib/cart-context";
import { formatPrice } from "@/lib/utils";

interface Product {
  id: string;
  name: string;
  slug: string;
  price: number;
  compare_at_price?: number;
  image?: string | null;
  image_url?: string | null;
  images?: string[];
  rating_avg?: number;
  rating_count?: number;
  discount_percent?: number;
  category_name?: string;
  vendor_name?: string;
  stock?: number;
  status?: string;
  colors?: string[];
  sizes?: string[];
  description?: string;
}

interface ProductCardProps {
  product: Product;
  className?: string;
}

const PLACEHOLDER_IMAGE = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='400' viewBox='0 0 400 400'%3E%3Crect width='400' height='400' fill='%23f8f0f0'/%3E%3Ctext x='200' y='200' font-family='Arial' font-size='16' fill='%23999' text-anchor='middle' dominant-baseline='middle'%3ENo Image%3C/text%3E%3C/svg%3E";

export default function ProductCard({ product, className = "" }: ProductCardProps) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isHovering, setIsHovering] = useState(false);
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [isAddingToCart, setIsAddingToCart] = useState(false);
  const [showQuickView, setShowQuickView] = useState(false);
  const [imageError, setImageError] = useState(false);
  const { addItem } = useCart();
  const autoSlideInterval = useRef<NodeJS.Timeout | null>(null);
  const [isMobile, setIsMobile] = useState(false);

  const { 
    id, 
    name, 
    slug, 
    price, 
    compare_at_price, 
    image_url,
    image,
    images: productImages = [],
    rating_avg = 4.5, 
    rating_count = 0,
    discount_percent = 0,
    category_name,
    vendor_name,
    stock = 0,
    colors = [],
    sizes = []
  } = product;

  const isInStock = stock > 0;
  const discount = compare_at_price && price < compare_at_price 
    ? Math.round(((compare_at_price - price) / compare_at_price) * 100)
    : discount_percent || 0;

  const getImages = (): string[] => {
    if (productImages && productImages.length > 0) {
      return productImages;
    }
    const singleImage = image_url || image;
    if (singleImage && singleImage.trim() !== '') {
      return [singleImage];
    }
    return [PLACEHOLDER_IMAGE];
  };

  const images = getImages();
  const hasMultipleImages = images.length > 1;

  // Check mobile
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Auto-slide images - starts immediately and continues always
  useEffect(() => {
    if (images.length <= 1) return;
    
    // Always auto-slide, regardless of hover state
    // Pause only when hovering on mobile (optional)
    const shouldPause = isMobile && isHovering;
    
    if (!shouldPause) {
      autoSlideInterval.current = setInterval(() => {
        setCurrentImageIndex((prev) => (prev + 1) % images.length);
        setImageError(false);
      }, 3000); // Change every 3 seconds
    } else {
      if (autoSlideInterval.current) {
        clearInterval(autoSlideInterval.current);
        autoSlideInterval.current = null;
      }
    }

    return () => {
      if (autoSlideInterval.current) {
        clearInterval(autoSlideInterval.current);
        autoSlideInterval.current = null;
      }
    };
  }, [images, isMobile, isHovering]);

  useEffect(() => {
    setImageError(false);
  }, [currentImageIndex]);

 const handleAddToCart = async (e: React.MouseEvent) => {
  e.preventDefault();
  e.stopPropagation();
  
  if (!isInStock) return;
  
  setIsAddingToCart(true);
  try {
    // Convert id to number - your backend expects a number
    const productId = typeof id === 'string' ? parseInt(id, 10) : id;
    
    // Call addItem with the correct signature: (productId: number, quantity?: number)
    await addItem(productId, 1);
    setTimeout(() => setIsAddingToCart(false), 1500);
  } catch (error) {
    setIsAddingToCart(false);
    console.error("Error adding to cart:", error);
  }
};


  const handleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsWishlisted(!isWishlisted);
  };

  const handleQuickView = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setShowQuickView(!showQuickView);
  };

  const handleImageError = () => {
    setImageError(true);
  };

  const displayImage = imageError ? PLACEHOLDER_IMAGE : images[currentImageIndex] || PLACEHOLDER_IMAGE;

  return (
    <div 
      className={`
        group relative bg-white rounded-xl overflow-hidden 
        shadow-sm hover:shadow-lg transition-all duration-300
        border border-gray-100 hover:border-[#c96e6e]/20
        ${className}
      `}
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
    >
      {/* Image Container */}
      <div className="relative w-full aspect-square bg-[#f8f0f0] overflow-hidden">
        <Link href={`/product/${slug}`} className="block w-full h-full">
          {/* Main Image */}
          <Image
            src={displayImage}
            alt={name}
            fill
            className={`
              object-cover transition-all duration-700 ease-in-out
              ${isHovering ? 'scale-105' : 'scale-100'}
            `}
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
            priority
            onError={handleImageError}
            unoptimized={displayImage.startsWith('data:')}
          />

          {/* No Image Placeholder */}
          {imageError && (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-gray-400">
              <ImageOff size={32} className="mb-1 opacity-50" />
              <span className="text-[10px]">No Image</span>
            </div>
          )}

          {/* Out of Stock Overlay */}
          {!isInStock && (
            <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
              <span className="bg-white/90 text-gray-800 px-3 py-1 rounded-full text-[10px] font-semibold backdrop-blur-sm">
                Out of Stock
              </span>
            </div>
          )}

          {/* Badges */}
          <div className="absolute top-2 left-2 flex flex-col gap-0.5">
            {discount > 0 && (
              <span className="px-2 py-0.5 bg-[#e74c3c] text-white text-[9px] font-bold rounded-full uppercase tracking-wider">
                -{discount}%
              </span>
            )}
            {!isInStock && (
              <span className="px-2 py-0.5 bg-gray-600 text-white text-[9px] font-bold rounded-full uppercase tracking-wider">
                Sold Out
              </span>
            )}
          </div>

          {/* Wishlist Button - Only on hover */}
          <button
            onClick={handleWishlist}
            className={`
              absolute top-2 right-2 bg-white hover:bg-[#f8e8e8] text-gray-600 hover:text-[#c96e6e] rounded-full p-1.5 shadow-lg transition-all duration-200 hover:scale-110
              ${isHovering ? 'opacity-100' : 'opacity-0'}
            `}
            aria-label="Add to wishlist"
          >
            <Heart size={15} className={isWishlisted ? 'fill-[#c96e6e] text-[#c96e6e]' : ''} />
          </button>
        </Link>
      </div>

      {/* Product Info */}
      <div className="p-2.5 space-y-0.5">
        <Link href={`/product/${slug}`} className="block">
          {/* Vendor & Category */}
          <div className="flex items-center gap-1 text-[8px] uppercase tracking-wider text-gray-400 font-medium truncate">
            {vendor_name && <span className="truncate">{vendor_name}</span>}
            {vendor_name && category_name && <span className="text-gray-300">•</span>}
            {category_name && <span className="truncate">{category_name}</span>}
          </div>

          {/* Product Name */}
          <h3 className="text-[11px] font-medium text-gray-800 line-clamp-1 hover:text-[#c96e6e] transition-colors">
            {name}
          </h3>

          {/* Rating */}
          {rating_count > 0 && (
            <div className="flex items-center gap-1">
              <div className="flex items-center gap-0.5">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    size={10}
                    className={`
                      ${i < Math.floor(rating_avg) 
                        ? 'fill-[#f5a623] text-[#f5a623]' 
                        : 'fill-gray-200 text-gray-200'
                      }
                    `}
                  />
                ))}
              </div>
              <span className="text-[9px] text-gray-400">({rating_count})</span>
            </div>
          )}

          {/* Price and Plus Button */}
          <div className="flex items-center justify-between mt-0.5">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-gray-900">
                {formatPrice(price)}
              </span>
              {compare_at_price && compare_at_price > price && (
                <span className="text-[9px] text-gray-400 line-through">
                  {formatPrice(compare_at_price)}
                </span>
              )}
            </div>
            
            {/* Plus Button */}
            {isInStock ? (
              <button
                onClick={handleAddToCart}
                disabled={isAddingToCart}
                className={`
                  rounded-full p-1 transition-all duration-300
                  flex items-center justify-center
                  ${isAddingToCart 
                    ? 'bg-green-500 text-white w-6 h-6' 
                    : 'bg-[#c96e6e] hover:bg-[#a85555] text-white hover:scale-110 w-6 h-6'
                  }
                  shadow-sm hover:shadow-md
                `}
                aria-label="Add to cart"
              >
                {isAddingToCart ? (
                  <Check size={12} className="animate-in fade-in zoom-in" />
                ) : (
                  <Plus size={12} />
                )}
              </button>
            ) : (
              <button
                disabled
                className="rounded-full p-1 bg-gray-300 text-white w-6 h-6 flex items-center justify-center cursor-not-allowed"
                aria-label="Out of stock"
              >
                <span className="text-[8px] font-bold">✕</span>
              </button>
            )}
          </div>

          {/* Colors Preview */}
          {colors && colors.length > 0 && (
            <div className="flex items-center gap-0.5 mt-0.5">
              {colors.slice(0, 4).map((color, index) => (
                <div
                  key={index}
                  className="w-2.5 h-2.5 rounded-full border border-gray-200"
                  style={{ backgroundColor: color }}
                  title={color}
                />
              ))}
              {colors.length > 4 && (
                <span className="text-[7px] text-gray-400 font-medium">
                  +{colors.length - 4}
                </span>
              )}
            </div>
          )}
        </Link>
      </div>

      {/* Quick View Modal */}
      {showQuickView && (
        <div 
          className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
          onClick={() => setShowQuickView(false)}
        >
          <div 
            className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <h2 className="text-xl font-bold text-gray-900">{name}</h2>
                <button
                  onClick={() => setShowQuickView(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ✕
                </button>
              </div>
              <div className="relative aspect-square bg-[#f8f0f0] rounded-xl overflow-hidden mb-4">
                <Image
                  src={displayImage}
                  alt={name}
                  fill
                  className="object-cover"
                  onError={handleImageError}
                  unoptimized={displayImage.startsWith('data:')}
                />
              </div>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-2xl font-bold text-gray-900">
                      {formatPrice(price)}
                    </span>
                    {compare_at_price && compare_at_price > price && (
                      <span className="ml-2 text-sm text-gray-400 line-through">
                        {formatPrice(compare_at_price)}
                      </span>
                    )}
                  </div>
                  {rating_count > 0 && (
                    <div className="flex items-center gap-1">
                      <Star size={16} className="fill-[#f5a623] text-[#f5a623]" />
                      <span className="text-sm font-medium">{rating_avg}</span>
                      <span className="text-sm text-gray-400">({rating_count})</span>
                    </div>
                  )}
                </div>
                {vendor_name && (
                  <p className="text-sm text-gray-500">By {vendor_name}</p>
                )}
                <p className="text-sm text-gray-600 line-clamp-3">
                  {product.description || "Beautiful product with premium quality."}
                </p>
                {sizes && sizes.length > 0 && (
                  <div>
                    <span className="text-sm font-medium text-gray-700">Sizes: </span>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {sizes.map((size) => (
                        <span 
                          key={size} 
                          className="px-3 py-1 text-sm border border-gray-200 rounded-full hover:border-[#c96e6e] hover:text-[#c96e6e] transition-colors cursor-pointer"
                        >
                          {size}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
                <button
                  onClick={handleAddToCart}
                  disabled={isAddingToCart || !isInStock}
                  className={`
                    w-full py-3 rounded-xl text-white font-semibold
                    transition-all duration-300 flex items-center justify-center gap-2
                    ${!isInStock 
                      ? 'bg-gray-400 cursor-not-allowed' 
                      : isAddingToCart 
                        ? 'bg-green-500' 
                        : 'bg-[#c96e6e] hover:bg-[#a85555]'
                    }
                  `}
                >
                  {!isInStock ? (
                    'Out of Stock'
                  ) : isAddingToCart ? (
                    <>
                      <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                      Adding...
                    </>
                  ) : (
                    <>
                      <ShoppingBag size={18} />
                      Add to Cart
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}