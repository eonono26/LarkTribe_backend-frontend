"use client";

import { useState } from "react";
import Image from "next/image";
import { mediaUrl } from "@/lib/api";

interface Props {
  images: Array<{ id: number; image: string; alt_text: string; order: number }>;
  productName: string;
  discountPercent?: number;
  productId: number | string;
}

export default function ProductImageGallery({ images, productName, discountPercent }: Props) {
  const [idx, setIdx] = useState(0);

  if (!images || images.length === 0) {
    return (
      <div className="relative aspect-[3/4] bg-stone-100">
        <div className="h-full w-full flex items-center justify-center text-stone-400 text-sm">No image</div>
      </div>
    );
  }

  const selected = images[idx];
  const hasMultiple = images.length > 1;

  return (
    <div className="w-full">
      {/* Main image — full width, no max-width cap */}
      <div className="relative w-full aspect-[3/4] bg-stone-100 overflow-hidden">
        <Image
          key={selected.id}
          src={mediaUrl(selected.image)}
          alt={selected.alt_text || productName}
          fill
          className="object-cover"
          sizes="(max-width: 1024px) 100vw, 60vw"
          priority
        />
        {discountPercent ? (
          <span className="absolute top-3 left-3 bg-black text-white text-[10px] font-medium px-2 py-1 uppercase tracking-wider">
            Sale {discountPercent}%
          </span>
        ) : null}
      </div>

      {/* Thumbnails — sharp, minimal */}
      {hasMultiple && (
        <div className="flex gap-2 mt-3 overflow-x-auto pb-1">
          {images.map((img, i) => (
            <button
              key={img.id}
              onClick={() => setIdx(i)}
              className={`relative shrink-0 w-16 h-20 overflow-hidden border ${i === idx ? "border-black" : "border-transparent"}`}
            >
              <Image src={mediaUrl(img.image)} alt="" fill className="object-cover" sizes="64px" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}