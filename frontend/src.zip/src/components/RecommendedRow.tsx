// components/RecommendedRow.tsx
'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import ProductCard from './ProductCard';
import type { ProductListItem } from '@/lib/types';
import { api } from '@/lib/api';

interface RecommendedRowProps {
  title: string;
  kind: 'similar' | 'fbt' | 'recommended';
  productId?: number;
  products?: ProductListItem[];
}

// Helper to get full image URL
const getFullImageUrl = (imagePath: string | null): string | null => {
  if (!imagePath) return null;
  // If it's already a full URL, return it
  if (imagePath.startsWith('http://') || imagePath.startsWith('https://')) {
    return imagePath;
  }
  // Otherwise prepend the base URL (use the same base as your API)
  const baseUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';
  return `${baseUrl}${imagePath}`;
};

// Map ProductListItem to the format ProductCard expects
const mapProductToCard = (product: ProductListItem) => {
  const fullImageUrl = getFullImageUrl(product.image);
  const fullImageUrls = product.images?.map(img => getFullImageUrl(img)).filter(Boolean) || [];
  
  return {
    id: String(product.id),
    name: product.name,
    slug: product.slug,
    price: parseFloat(product.price),
    compare_at_price: product.compare_at_price ? parseFloat(product.compare_at_price) : undefined,
    image: fullImageUrl,
    image_url: fullImageUrl,
    images: fullImageUrls,
    rating_avg: parseFloat(product.rating_avg),
    rating_count: product.rating_count,
    discount_percent: product.discount_percent || 0,
    vendor_name: product.vendor_name,
    category_name: product.category_name,
    stock: product.stock || 0,
    status: product.status || 'active',
    is_featured: product.is_featured || false,
  };
};

export default function RecommendedRow({ 
  title, 
  kind, 
  productId, 
  products: initialProducts 
}: RecommendedRowProps) {
  const [products, setProducts] = useState<ProductListItem[]>(initialProducts || []);
  const [loading, setLoading] = useState(!initialProducts);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (initialProducts) {
      setProducts(initialProducts);
      setLoading(false);
      return;
    }

    const fetchProducts = async () => {
      if (!productId) {
        setLoading(false);
        return;
      }

      try {
        let data;
        if (kind === 'recommended') {
          data = await api.recommendedForYou();
        } else if (kind === 'similar') {
          data = await api.similarProducts(productId);
        } else if (kind === 'fbt') {
          data = await api.frequentlyBoughtTogether(productId);
        }
        
        setProducts(data || []);
        setError(null);
      } catch (err) {
        console.error(`Failed to fetch ${kind} products:`, err);
        setError('Failed to load recommendations');
        setProducts([]);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, [kind, productId, initialProducts]);

  if (loading) {
    return (
      <section className="container-shell mt-14">
        <h2 className="font-display text-2xl font-bold mb-5">{title}</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="bg-gray-200 aspect-square rounded-lg"></div>
              <div className="h-4 bg-gray-200 rounded mt-2"></div>
              <div className="h-3 bg-gray-200 rounded mt-1 w-2/3"></div>
            </div>
          ))}
        </div>
      </section>
    );
  }

  if (error || products.length === 0) {
    return null;
  }

  return (
    <section className="container-shell mt-14">
      <div className="flex items-baseline justify-between mb-5">
        <h2 className="font-display text-2xl font-bold">{title}</h2>
        <Link href="/category/women" className="text-sm font-semibold underline">
          View all
        </Link>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
        {products.slice(0, 5).map((product) => (
          <ProductCard key={product.id} product={mapProductToCard(product)} />
        ))}
      </div>
    </section>
  );
}