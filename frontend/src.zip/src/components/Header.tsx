"use client";

import Link from "next/link";
import { useEffect, useState, useRef } from "react";
import { 
  ShoppingBag, 
  User, 
  Heart, 
  MapPin, 
  ChevronDown, 
  Menu, 
  Search,
  X,
  DollarSign,
  Sparkles,
  Tag,
  Truck,
  Shield,
  Clock,
  TrendingUp,
  ArrowRight
} from "lucide-react";
import { useCart } from "@/lib/cart-context";
import { isLoggedIn } from "@/lib/auth";
import NotificationBell from "./NotificationBell";
import LanguageSwitcher from "./LanguageSwitcher";
import LocationModal from "./LocationModal";

const DEPT_COLOR: Record<string, string> = {
  women: "var(--dept-women)",
  kids: "var(--dept-kids)",
  beauty: "var(--dept-beauty)",
  maternity: "var(--dept-maternity)",
  "home-lifestyle": "var(--dept-home)",
};

const DEFAULT_LOCATION = { label: "Nairobi, Kenya", lat: -1.2921, lng: 36.8219 };

const CURRENCIES = [
  { code: "KES", symbol: "KSh", label: "Kenyan Shilling" },
  { code: "USD", symbol: "$", label: "US Dollar" },
  { code: "EUR", symbol: "€", label: "Euro" },
  { code: "GBP", symbol: "£", label: "British Pound" },
  { code: "NGN", symbol: "₦", label: "Nigerian Naira" },
  { code: "ZAR", symbol: "R", label: "South African Rand" },
  { code: "UGX", symbol: "USh", label: "Ugandan Shilling" },
  { code: "TZS", symbol: "TSh", label: "Tanzanian Shilling" },
];

const LANGUAGES = [
  { code: "en", label: "English", native: "English", flag: "🇬🇧" },
  { code: "sw", label: "Swahili", native: "Kiswahili", flag: "🇰🇪" },
  { code: "fr", label: "French", native: "Français", flag: "🇫🇷" },
  { code: "es", label: "Spanish", native: "Español", flag: "🇪🇸" },
  { code: "de", label: "German", native: "Deutsch", flag: "🇩🇪" },
  { code: "it", label: "Italian", native: "Italiano", flag: "🇮🇹" },
  { code: "pt", label: "Portuguese", native: "Português", flag: "🇵🇹" },
  { code: "ar", label: "Arabic", native: "العربية", flag: "🇸🇦" },
  { code: "hi", label: "Hindi", native: "हिन्दी", flag: "🇮🇳" },
  { code: "zh", label: "Chinese", native: "中文", flag: "🇨🇳" },
  { code: "ja", label: "Japanese", native: "日本語", flag: "🇯🇵" },
  { code: "ko", label: "Korean", native: "한국어", flag: "🇰🇷" },
  { code: "ru", label: "Russian", native: "Русский", flag: "🇷🇺" },
  { code: "af", label: "Afrikaans", native: "Afrikaans", flag: "🇿🇦" },
  { code: "am", label: "Amharic", native: "አማርኛ", flag: "🇪🇹" },
];

const TRENDING_SEARCHES = [
  "Baby Dresses",
  "Women's Tops",
  "Kids Shoes",
  "Maternity Wear",
  "Baby Onesies",
  "Women's Dresses",
  "Accessories",
  "Beauty Products"
];

export default function Header() {
  const [categories, setCategories] = useState<any[]>([]);
  const [loggedIn, setLoggedIn] = useState(false);
  const [locationOpen, setLocationOpen] = useState(false);
  const [location, setLocation] = useState(DEFAULT_LOCATION);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [currencyOpen, setCurrencyOpen] = useState(false);
  const [languageOpen, setLanguageOpen] = useState(false);
  const [selectedCurrency, setSelectedCurrency] = useState(CURRENCIES[0]);
  const [selectedLanguage, setSelectedLanguage] = useState(LANGUAGES[0]);
  const [searchFocused, setSearchFocused] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const { itemCount, openDrawer } = useCart();
  const currencyRef = useRef<HTMLDivElement>(null);
  const languageRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLDivElement>(null);

  // Load recent searches from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("recent_searches");
    if (saved) {
      try {
        setRecentSearches(JSON.parse(saved));
      } catch (e) {
        setRecentSearches([]);
      }
    }
  }, []);

  // Save recent searches
  const saveRecentSearch = (query: string) => {
    if (!query.trim()) return;
    const updated = [query, ...recentSearches.filter(s => s !== query)].slice(0, 5);
    setRecentSearches(updated);
    localStorage.setItem("recent_searches", JSON.stringify(updated));
  };

  // Handle search submission
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      saveRecentSearch(searchQuery.trim());
      window.location.href = `/search?q=${encodeURIComponent(searchQuery.trim())}`;
    }
  };

  // Clear recent searches
  const clearRecentSearches = () => {
    setRecentSearches([]);
    localStorage.removeItem("recent_searches");
  };

  // Close search on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setSearchFocused(false);
      }
      if (currencyRef.current && !currencyRef.current.contains(event.target as Node)) {
        setCurrencyOpen(false);
      }
      if (languageRef.current && !languageRef.current.contains(event.target as Node)) {
        setLanguageOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    async function loadCategories() {
      try {
        const response = await fetch('http://127.0.0.1:8000/api/catalog/categories/');
        if (response.ok) {
          const data = await response.json();
          setCategories(data.results || []);
        }
      } catch (error) {
        console.error('Error fetching categories:', error);
      }
    }
    
    loadCategories();
    setLoggedIn(isLoggedIn());
    const saved = localStorage.getItem("duka_location");
    if (saved) setLocation(JSON.parse(saved));
    
    const savedCurrency = localStorage.getItem("duka_currency");
    if (savedCurrency) {
      const found = CURRENCIES.find(c => c.code === savedCurrency);
      if (found) setSelectedCurrency(found);
    }

    const savedLanguage = localStorage.getItem("duka_language");
    if (savedLanguage) {
      const found = LANGUAGES.find(l => l.code === savedLanguage);
      if (found) setSelectedLanguage(found);
    }
  }, []);

  function saveLocation(loc: typeof DEFAULT_LOCATION) {
    setLocation(loc);
    localStorage.setItem("duka_location", JSON.stringify(loc));
  }

  function handleCurrencyChange(currency: typeof CURRENCIES[0]) {
    setSelectedCurrency(currency);
    localStorage.setItem("duka_currency", currency.code);
    setCurrencyOpen(false);
  }

  function handleLanguageChange(language: typeof LANGUAGES[0]) {
    setSelectedLanguage(language);
    localStorage.setItem("duka_language", language.code);
    setLanguageOpen(false);
  }

  const duplicatedCategories = categories.length > 0 ? [...categories, ...categories, ...categories] : [];

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
      {/* Promo Bar - Modern Soft Gradient */}
      <div className="bg-gradient-to-r from-[#f8e8e8] via-[#f5e6d3] to-[#e8d5d5] text-[#4a3728] text-xs md:text-sm font-medium py-1.5 md:py-2.5 overflow-hidden">
        <div className="container-shell">
          <div className="promo-marquee-wrapper">
            <div className="promo-marquee-track flex items-center gap-4 md:gap-8">
              <span className="flex items-center gap-1.5 md:gap-2 whitespace-nowrap">
                <span className="inline-block w-1 h-1 md:w-1.5 md:h-1.5 rounded-full bg-[#d4a5a5] flex-shrink-0"></span>
                <span className="truncate">Free delivery on orders over KSh 5,000</span>
              </span>
              <span className="flex items-center gap-1.5 md:gap-2 whitespace-nowrap">
                <span className="inline-block w-1 h-1 md:w-1.5 md:h-1.5 rounded-full bg-[#c4a882] flex-shrink-0"></span>
                <span className="truncate">Pay with M-PESA at checkout</span>
              </span>
              <span className="flex items-center gap-1.5 md:gap-2 whitespace-nowrap">
                <span className="inline-block w-1 h-1 md:w-1.5 md:h-1.5 rounded-full bg-[#b8a0a0] flex-shrink-0"></span>
                <span className="truncate">New vendors joining weekly</span>
              </span>
              <span className="flex items-center gap-1.5 md:gap-2 whitespace-nowrap">
                <span className="inline-block w-1 h-1 md:w-1.5 md:h-1.5 rounded-full bg-[#d4a5a5] flex-shrink-0"></span>
                <span className="truncate">Exclusive deals daily</span>
              </span>
              {/* Duplicate for seamless scroll */}
              <span className="flex items-center gap-1.5 md:gap-2 whitespace-nowrap">
                <span className="inline-block w-1 h-1 md:w-1.5 md:h-1.5 rounded-full bg-[#c4a882] flex-shrink-0"></span>
                <span className="truncate">Free delivery on orders over KSh 5,000</span>
              </span>
              <span className="flex items-center gap-1.5 md:gap-2 whitespace-nowrap">
                <span className="inline-block w-1 h-1 md:w-1.5 md:h-1.5 rounded-full bg-[#b8a0a0] flex-shrink-0"></span>
                <span className="truncate">Pay with M-PESA at checkout</span>
              </span>
              <span className="flex items-center gap-1.5 md:gap-2 whitespace-nowrap">
                <span className="inline-block w-1 h-1 md:w-1.5 md:h-1.5 rounded-full bg-[#d4a5a5] flex-shrink-0"></span>
                <span className="truncate">New vendors joining weekly</span>
              </span>
              <span className="flex items-center gap-1.5 md:gap-2 whitespace-nowrap">
                <span className="inline-block w-1 h-1 md:w-1.5 md:h-1.5 rounded-full bg-[#c4a882] flex-shrink-0"></span>
                <span className="truncate">Exclusive deals daily</span>
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Header */}
      <div className="md:hidden">
        <div className="container-shell py-2">
          {/* Top row with logo and actions */}
          <div className="flex items-center justify-between gap-2">
            <button 
              onClick={() => setMobileNavOpen((o) => !o)} 
              aria-label="Menu" 
              className="p-1.5 rounded-lg hover:bg-[#f8e8e8] transition-colors shrink-0"
            >
              <Menu size={22} className="text-gray-700" />
            </button>
            
            <Link href="/" className="flex items-center shrink-0">
              <span className="text-xl font-bold text-[#c96e6e]">
                LarkTribe
              </span>
            </Link>
            
            <div className="flex items-center gap-1 ml-auto shrink-0">
              <NotificationBell />
              <button 
                aria-label="Cart" 
                onClick={openDrawer} 
                className="p-1.5 rounded-lg hover:bg-[#f8e8e8] transition-colors relative"
              >
                <ShoppingBag size={20} className="text-gray-700" />
                {itemCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 bg-[#c96e6e] text-white text-[9px] font-bold rounded-full h-4.5 w-4.5 flex items-center justify-center shadow-lg">
                    {itemCount}
                  </span>
                )}
              </button>
            </div>
          </div>

          {/* Location and Search row */}
          <div className="flex flex-col gap-2 mt-2">
            <div className="flex items-center justify-between">
              <button
                onClick={() => setLocationOpen(true)}
                className="flex items-center gap-1.5 text-xs font-medium hover:opacity-70 px-2 py-1 rounded-lg hover:bg-[#f8e8e8] transition-colors"
              >
                <MapPin size={14} className="shrink-0 text-[#c96e6e]" />
                <span className="text-gray-600">Deliver to</span>
                <span className="font-semibold text-gray-800 max-w-[80px] truncate">{location.label}</span>
                <ChevronDown size={12} className="text-gray-400" />
              </button>
              
              <div className="flex items-center gap-1">
                {/* Language selector */}
                <button
                  onClick={() => setLanguageOpen(!languageOpen)}
                  className="flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-[#f8e8e8] transition-colors text-xs"
                >
                  <span className="text-sm leading-none">{selectedLanguage.flag}</span>
                  <ChevronDown size={10} className="text-gray-400" />
                </button>

                {/* Currency selector */}
                <button
                  onClick={() => setCurrencyOpen(!currencyOpen)}
                  className="flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-[#f8e8e8] transition-colors text-xs font-medium"
                >
                  <span>{selectedCurrency.symbol}</span>
                  <ChevronDown size={10} className="text-gray-400" />
                </button>
              </div>
            </div>
            
            {/* Search Bar with suggestions */}
            <div className="relative" ref={searchRef}>
              <form onSubmit={handleSearch}>
                <div className="relative">
                  <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search products..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onFocus={() => setSearchFocused(true)}
                    className="w-full py-2 pl-9 pr-3 rounded-full border border-gray-200 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-[#c96e6e] focus:border-transparent text-sm"
                  />
                  {searchQuery && (
                    <button
                      type="button"
                      onClick={() => setSearchQuery("")}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      <X size={14} />
                    </button>
                  )}
                </div>
              </form>

              {/* Search Suggestions */}
              {searchFocused && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden z-50">
                  {/* Recent Searches */}
                  {recentSearches.length > 0 && (
                    <div className="p-3">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider flex items-center gap-1.5">
                          <Clock size={12} />
                          Recent Searches
                        </span>
                        <button
                          onClick={clearRecentSearches}
                          className="text-xs text-gray-400 hover:text-gray-600 transition-colors"
                        >
                          Clear all
                        </button>
                      </div>
                      <div className="space-y-1">
                        {recentSearches.map((item, index) => (
                          <button
                            key={index}
                            onClick={() => {
                              setSearchQuery(item);
                              saveRecentSearch(item);
                              window.location.href = `/search?q=${encodeURIComponent(item)}`;
                            }}
                            className="w-full text-left px-3 py-2 rounded-lg hover:bg-[#f8e8e8] transition-colors flex items-center gap-3 text-sm"
                          >
                            <Clock size={14} className="text-gray-400 flex-shrink-0" />
                            <span className="text-gray-700">{item}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Trending Searches */}
                  <div className="p-3 border-t border-gray-100">
                    <div className="flex items-center gap-1.5 mb-2">
                      <TrendingUp size={12} className="text-[#c96e6e]" />
                      <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                        Trending Now
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {TRENDING_SEARCHES.map((item, index) => (
                        <button
                          key={index}
                          onClick={() => {
                            setSearchQuery(item);
                            saveRecentSearch(item);
                            window.location.href = `/search?q=${encodeURIComponent(item)}`;
                          }}
                          className="px-3 py-1.5 rounded-full text-xs font-medium bg-[#f8e8e8] hover:bg-[#c96e6e] hover:text-white transition-all duration-200 text-gray-700 border border-[#e8d5d5] hover:border-[#c96e6e]"
                        >
                          {item}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* View All */}
                  <div className="p-3 border-t border-gray-100 bg-[#f8e8e8]/30">
                    <button
                      onClick={() => {
                        if (searchQuery.trim()) {
                          saveRecentSearch(searchQuery.trim());
                          window.location.href = `/search?q=${encodeURIComponent(searchQuery.trim())}`;
                        }
                      }}
                      className="w-full text-center text-sm font-medium text-[#c96e6e] hover:text-[#a85555] transition-colors flex items-center justify-center gap-1"
                    >
                      <span>View all results</span>
                      <ArrowRight size={14} />
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Mobile Dropdown Nav */}
        {mobileNavOpen && (
          <div className="border-t border-gray-200 bg-white shadow-lg max-h-[70vh] overflow-y-auto">
            <nav className="container-shell py-2">
              {categories.map((c) => (
                <Link
                  key={c.id}
                  href={`/category/${c.slug}`}
                  onClick={() => setMobileNavOpen(false)}
                  className="flex items-center justify-between py-3 border-b border-gray-100 last:border-0 hover:bg-[#f8e8e8] px-3 rounded-lg transition-colors"
                >
                  <span style={{ color: DEPT_COLOR[c.department?.slug] ?? "var(--color-ink)" }}>
                    {c.name}
                  </span>
                  <ChevronDown size={14} className="rotate-[-90deg] text-gray-400" />
                </Link>
              ))}
              <Link 
                href="/deals" 
                onClick={() => setMobileNavOpen(false)} 
                className="flex items-center justify-between py-3 border-b border-gray-100 hover:bg-[#f8e8e8] px-3 rounded-lg transition-colors"
              >
                <span className="text-[#c96e6e] font-bold">Deals 🔥</span>
                <ChevronDown size={14} className="rotate-[-90deg] text-gray-400" />
              </Link>
              <Link 
                href="/brands" 
                onClick={() => setMobileNavOpen(false)} 
                className="flex items-center justify-between py-3 border-b border-gray-100 hover:bg-[#f8e8e8] px-3 rounded-lg transition-colors"
              >
                <span className="text-gray-600">Brands</span>
                <ChevronDown size={14} className="rotate-[-90deg] text-gray-400" />
              </Link>
              <Link 
                href="/vendor" 
                onClick={() => setMobileNavOpen(false)} 
                className="flex items-center justify-between py-3 hover:bg-[#f8e8e8] px-3 rounded-lg transition-colors"
              >
                <span className="text-gray-600">Sell on LarkTribe</span>
                <ChevronDown size={14} className="rotate-[-90deg] text-gray-400" />
              </Link>
            </nav>
          </div>
        )}

        {/* Mobile Language Dropdown */}
        {languageOpen && (
          <div className="absolute left-4 right-4 mt-1 bg-white rounded-xl shadow-xl border border-gray-100 py-2 z-50 max-h-60 overflow-y-auto">
            {LANGUAGES.map((language) => (
              <button
                key={language.code}
                onClick={() => {
                  handleLanguageChange(language);
                  setLanguageOpen(false);
                }}
                className={`
                  w-full px-4 py-2.5 text-left hover:bg-[#f8e8e8] transition-colors flex items-center justify-between
                  ${selectedLanguage.code === language.code ? 'bg-[#f8e8e8] text-[#c96e6e]' : 'text-gray-700'}
                `}
              >
                <span className="flex items-center gap-3">
                  <span className="text-lg">{language.flag}</span>
                  <span className="font-medium text-sm">{language.native}</span>
                </span>
                <span className="text-xs text-gray-500">{language.label}</span>
              </button>
            ))}
          </div>
        )}

        {/* Mobile Currency Dropdown */}
        {currencyOpen && (
          <div className="absolute right-4 left-4 mt-1 bg-white rounded-xl shadow-xl border border-gray-100 py-2 z-50 max-h-60 overflow-y-auto">
            {CURRENCIES.map((currency) => (
              <button
                key={currency.code}
                onClick={() => {
                  handleCurrencyChange(currency);
                  setCurrencyOpen(false);
                }}
                className={`
                  w-full px-4 py-2.5 text-left hover:bg-[#f8e8e8] transition-colors flex items-center justify-between
                  ${selectedCurrency.code === currency.code ? 'bg-[#f8e8e8] text-[#c96e6e]' : 'text-gray-700'}
                `}
              >
                <span className="flex items-center gap-3">
                  <span className="font-semibold">{currency.symbol}</span>
                  <span className="text-sm">{currency.code}</span>
                </span>
                <span className="text-xs text-gray-500">{currency.label}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Desktop Header */}
      <div className="hidden md:block">
        <div className="container-shell py-4">
          {/* Desktop main row */}
          <div className="flex items-center gap-6">
            {/* Logo - Text */}
            <Link href="/" className="flex items-center shrink-0">
              <span className="text-2xl font-bold text-[#c96e6e] hover:opacity-80 transition-opacity">
                LarkTribe
              </span>
            </Link>

            {/* Location */}
            <button
              onClick={() => setLocationOpen(true)}
              className="flex items-center gap-2 text-sm font-medium shrink-0 hover:opacity-70 max-w-[170px] font-body px-3 py-2 rounded-lg hover:bg-[#f8e8e8] transition-colors group"
            >
              <MapPin size={18} className="shrink-0 text-[#c96e6e] group-hover:scale-110 transition-transform" />
              <span className="text-left leading-tight">
                <span className="block text-xs text-gray-500 font-normal">
                  Deliver to
                </span>
                <span className="block text-sm font-semibold truncate text-gray-800">
                  {location.label}
                </span>
              </span>
              <ChevronDown size={14} className="shrink-0 text-gray-400" />
            </button>

            {/* Search Bar with suggestions */}
            <div className="flex-1 relative" ref={searchRef}>
              <form onSubmit={handleSearch}>
                <div className={`
                  relative flex items-center rounded-full transition-all duration-300
                  ${searchFocused 
                    ? 'ring-2 ring-[#c96e6e] shadow-lg shadow-[#c96e6e]/15' 
                    : 'hover:shadow-md'
                  }
                `}>
                  <Search 
                    size={20} 
                    className={`absolute left-4 transition-colors duration-300 ${
                      searchFocused ? 'text-[#c96e6e]' : 'text-gray-400'
                    }`} 
                  />
                  <input
                    type="text"
                    placeholder="Search for products, categories, or brands..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onFocus={() => setSearchFocused(true)}
                    className={`
                      w-full py-3 pl-12 pr-4 rounded-full border-2 transition-all duration-300
                      ${searchFocused 
                        ? 'border-[#c96e6e] bg-white' 
                        : 'border-gray-200 bg-gray-50 hover:border-gray-300'
                      }
                      focus:outline-none text-sm placeholder-gray-400
                    `}
                  />
                  {searchQuery && (
                    <button
                      type="button"
                      onClick={() => setSearchQuery("")}
                      className="absolute right-20 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                    >
                      <X size={18} />
                    </button>
                  )}
                  <button 
                    type="submit"
                    className="absolute right-2 bg-[#c96e6e] hover:bg-[#a85555] text-white px-6 py-1.5 rounded-full text-sm font-semibold transition-all duration-200 shadow-md hover:shadow-lg"
                  >
                    Search
                  </button>
                </div>
              </form>

              {/* Search Suggestions - Desktop */}
              {searchFocused && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden z-50">
                  {/* Recent Searches */}
                  {recentSearches.length > 0 && (
                    <div className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider flex items-center gap-1.5">
                          <Clock size={14} />
                          Recent Searches
                        </span>
                        <button
                          onClick={clearRecentSearches}
                          className="text-xs text-gray-400 hover:text-gray-600 transition-colors"
                        >
                          Clear all
                        </button>
                      </div>
                      <div className="space-y-1">
                        {recentSearches.map((item, index) => (
                          <button
                            key={index}
                            onClick={() => {
                              setSearchQuery(item);
                              saveRecentSearch(item);
                              window.location.href = `/search?q=${encodeURIComponent(item)}`;
                            }}
                            className="w-full text-left px-3 py-2 rounded-lg hover:bg-[#f8e8e8] transition-colors flex items-center gap-3 text-sm"
                          >
                            <Clock size={16} className="text-gray-400 flex-shrink-0" />
                            <span className="text-gray-700">{item}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Trending Searches */}
                  <div className="p-4 border-t border-gray-100">
                    <div className="flex items-center gap-1.5 mb-3">
                      <TrendingUp size={14} className="text-[#c96e6e]" />
                      <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                        Trending Now
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {TRENDING_SEARCHES.map((item, index) => (
                        <button
                          key={index}
                          onClick={() => {
                            setSearchQuery(item);
                            saveRecentSearch(item);
                            window.location.href = `/search?q=${encodeURIComponent(item)}`;
                          }}
                          className="px-4 py-2 rounded-full text-sm font-medium bg-[#f8e8e8] hover:bg-[#c96e6e] hover:text-white transition-all duration-200 text-gray-700 border border-[#e8d5d5] hover:border-[#c96e6e]"
                        >
                          {item}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* View All */}
                  <div className="p-4 border-t border-gray-100 bg-[#f8e8e8]/30">
                    <button
                      onClick={() => {
                        if (searchQuery.trim()) {
                          saveRecentSearch(searchQuery.trim());
                          window.location.href = `/search?q=${encodeURIComponent(searchQuery.trim())}`;
                        }
                      }}
                      className="w-full text-center text-sm font-medium text-[#c96e6e] hover:text-[#a85555] transition-colors flex items-center justify-center gap-2"
                    >
                      <span>See all results</span>
                      <ArrowRight size={16} />
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Right actions */}
            <div className="flex items-center gap-3 ml-auto shrink-0">
              {/* Language Selector */}
              <div className="relative" ref={languageRef}>
                <button
                  onClick={() => setLanguageOpen(!languageOpen)}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg hover:bg-[#f8e8e8] transition-colors text-sm font-medium"
                >
                  <span className="text-lg leading-none">{selectedLanguage.flag}</span>
                  <span className="hidden xl:inline">{selectedLanguage.code.toUpperCase()}</span>
                  <ChevronDown size={14} className={`text-gray-400 transition-transform duration-200 ${languageOpen ? 'rotate-180' : ''}`} />
                </button>
                
                {languageOpen && (
                  <div className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-gray-100 py-2 overflow-hidden z-50 max-h-80 overflow-y-auto">
                    {LANGUAGES.map((language) => (
                      <button
                        key={language.code}
                        onClick={() => handleLanguageChange(language)}
                        className={`
                          w-full px-4 py-2.5 text-left hover:bg-[#f8e8e8] transition-colors flex items-center justify-between
                          ${selectedLanguage.code === language.code ? 'bg-[#f8e8e8] text-[#c96e6e]' : 'text-gray-700'}
                        `}
                      >
                        <span className="flex items-center gap-3">
                          <span className="text-xl">{language.flag}</span>
                          <span className="font-medium">{language.native}</span>
                        </span>
                        <span className="text-sm text-gray-500">{language.label}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Currency Selector */}
              <div className="relative" ref={currencyRef}>
                <button
                  onClick={() => setCurrencyOpen(!currencyOpen)}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg hover:bg-[#f8e8e8] transition-colors text-sm font-medium"
                >
                  <DollarSign size={18} className="text-gray-600" />
                  <span>{selectedCurrency.symbol}</span>
                  <ChevronDown size={14} className={`text-gray-400 transition-transform duration-200 ${currencyOpen ? 'rotate-180' : ''}`} />
                </button>
                
                {currencyOpen && (
                  <div className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-gray-100 py-2 overflow-hidden z-50 max-h-80 overflow-y-auto">
                    {CURRENCIES.map((currency) => (
                      <button
                        key={currency.code}
                        onClick={() => handleCurrencyChange(currency)}
                        className={`
                          w-full px-4 py-2.5 text-left hover:bg-[#f8e8e8] transition-colors flex items-center justify-between
                          ${selectedCurrency.code === currency.code ? 'bg-[#f8e8e8] text-[#c96e6e]' : 'text-gray-700'}
                        `}
                      >
                        <span className="flex items-center gap-3">
                          <span className="font-semibold">{currency.symbol}</span>
                          <span>{currency.code}</span>
                        </span>
                        <span className="text-sm text-gray-500">{currency.label}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <Link
                href="/deals"
                className="hidden xl:block text-sm font-semibold text-[#c96e6e] hover:text-[#a85555] transition-colors"
              >
                Deals 🔥
              </Link>

              <Link
                href="/brands"
                className="hidden xl:block text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors"
              >
                Brands
              </Link>

              <Link
                href="/vendor"
                className="hidden xl:block text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors"
              >
                Sell
              </Link>
              
              <Link 
                href={loggedIn ? "/account/wishlist" : "/login"} 
                aria-label="Account" 
                className="p-2 rounded-full hover:bg-[#f8e8e8] transition-colors relative group"
              >
                <User size={22} className="text-gray-700 group-hover:text-[#c96e6e] transition-colors" />
              </Link>
              
              <Link 
                href={loggedIn ? "/account/wishlist" : "/login"} 
                aria-label="Wishlist" 
                className="p-2 rounded-full hover:bg-[#f8e8e8] transition-colors relative group"
              >
                <Heart size={22} className="text-gray-700 group-hover:text-[#c96e6e] transition-colors" />
              </Link>
              
              <NotificationBell />
              
              <button 
                aria-label="Cart" 
                onClick={openDrawer} 
                className="p-2 rounded-full hover:bg-[#f8e8e8] transition-colors relative group"
              >
                <ShoppingBag size={22} className="text-gray-700 group-hover:text-[#c96e6e] transition-colors" />
                {itemCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-[#c96e6e] text-white text-[10px] font-bold rounded-full h-5 w-5 flex items-center justify-center shadow-lg">
                    {itemCount}
                  </span>
                )}
              </button>
            </div>
          </div>

          {/* Desktop category nav */}
          {categories.length > 0 && (
            <div className="mt-3">
              <div className="category-marquee-wrapper bg-[#f8e8e8]/30 rounded-2xl px-4 py-2 border border-[#e8d5d5]">
                <div className="category-marquee-track flex items-center gap-8">
                  {duplicatedCategories.map((c, index) => (
                    <Link
                      key={`${c.id}-${index}`}
                      href={`/category/${c.slug}`}
                      className="category-marquee-item text-sm font-medium whitespace-nowrap hover:scale-105 transition-transform px-3 py-1.5 rounded-lg hover:bg-white/80"
                      style={{
                        color: DEPT_COLOR[c.department?.slug] ?? "var(--color-ink)",
                      }}
                    >
                      {c.name}
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          )}

          {categories.length === 0 && (
            <div className="mt-3">
              <div className="text-sm text-gray-400 py-2 px-4 bg-[#f8e8e8]/30 rounded-xl">Loading categories...</div>
            </div>
          )}
        </div>
      </div>

      <LocationModal open={locationOpen} onClose={() => setLocationOpen(false)} onSave={saveLocation} initialLocation={location} />
    </header>
  );
}