"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import {
  Menu,
  Search,
  X,
  Heart,
  ShoppingBag,
  ChevronDown,
  User2,
} from "lucide-react";
import { useCart } from "@/lib/cart-context";
import { isLoggedIn, auth, type AuthUser } from "@/lib/auth";
import { api, mediaUrl } from "@/lib/api";
import type { Wishlist, ProductListItem } from "@/lib/types";
import {
  MegaPanel,
  MobileMenuBody,
  buildTree,
  type MenuData,
} from "@/components/MegaMenu";

const NAV_LINKS = [
  { href: "/shop?stage=baby", label: "Babies", source: { stage: "baby" } },
  { href: "/shop?stage=kids", label: "Kids", source: { stage: "kids" } },
  {
    href: "/shop?department=women",
    label: "Women",
    source: { department: "women" },
  },
  {
    href: "/shop?department=men",
    label: "Men",
    source: { department: "men" },
  },
] as const;

const GENDER_QUICK = (stage: string) => [
  { label: "Girls", href: `/shop?stage=${stage}&gender=girls` },
  { label: "Boys", href: `/shop?stage=${stage}&gender=boys` },
  { label: "Unisex", href: `/shop?stage=${stage}&gender=unisex` },
];

// Session-scoped key: dismissal lasts for the tab session, then the bar
// comes back. This avoids a single accidental dismissal hiding it forever.
const APP_URL = process.env.NEXT_PUBLIC_APP_URL || "/download";

const ANNOUNCEMENT_KEY = "announcementDismissed_session_v1";

export default function Header() {
  const router = useRouter();
  const { itemCount, openDrawer } = useCart();

  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [suggestions, setSuggestions] = useState<ProductListItem[]>([]);
  const [searching, setSearching] = useState(false);
  const [user, setUser] = useState<AuthUser | null>(null);
  const [wishlistCount, setWishlistCount] = useState(0);
  const [menus, setMenus] = useState<Record<string, MenuData>>({});
  const [closedMenu, setClosedMenu] = useState<string | null>(null);
  const [mobileExpanded, setMobileExpanded] = useState<string | null>(null);

  // Hydration-safe flags: stay false during SSR + first client render.
  const [mounted, setMounted] = useState(false);
  const [showAnnouncement, setShowAnnouncement] = useState(false);

  const searchBoxRef = useRef<HTMLDivElement>(null);
  const headerRef = useRef<HTMLElement>(null);

  // Publish the pinned header's height as a CSS variable (used by sticky bars that sit under it).
  useEffect(() => {
    const el = headerRef.current;
    if (!el) return;
    const publish = () =>
      document.documentElement.style.setProperty("--header-h", `${el.offsetHeight}px`);
    publish();
    const ro = new ResizeObserver(publish);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  // After mount, check sessionStorage for dismissal and set visibility.
  useEffect(() => {
    setMounted(true);

    if (typeof window === "undefined") return;

    try {
      // Clean up any stale localStorage key from earlier versions so it
      // can't keep the bar hidden.
      localStorage.removeItem("announcementDismissedV2");

      const dismissed = sessionStorage.getItem(ANNOUNCEMENT_KEY);
      setShowAnnouncement(dismissed !== "1");
    } catch {
      // Storage unavailable → default to showing the bar.
      setShowAnnouncement(true);
    }
  }, []);

  useEffect(() => {
    let cancelled = false;
    let allCats: ReturnType<typeof api.categories> | null = null;

    const loadAll = () => (allCats ??= api.categories({ page_size: "300" }));

    const put = (label: string, data: MenuData) => {
      if (!cancelled) {
        setMenus((prev) => ({ ...prev, [label]: data }));
      }
    };

    NAV_LINKS.forEach((link) => {
      const src = link.source;
      if (!src) return;

      if ("department" in src) {
        api
          .categories({ department: src.department, page_size: "300" })
          .then((r) =>
            put(link.label, {
              nodes: buildTree(
                `department=${src.department}`,
                r.results || []
              ),
              quick: [],
            })
          )
          .catch(() => {});
        return;
      }

      Promise.all([
        loadAll(),
        api.categories({ stage: src.stage, page_size: "300" }),
        api.ageGroupsByStage(src.stage),
      ])
        .then(([all, inStage, ages]) => {
          const nodes = buildTree(
            `stage=${src.stage}`,
            all.results || [],
            new Set((inStage.results || []).map((c) => c.id))
          );

          const ageLinks = (ages.age_groups || [])
            .filter(
              (a) => a.is_active !== false && (a.product_count ?? 0) > 0
            )
            .sort((x, y) => (x.order ?? 0) - (y.order ?? 0))
            .map((a) => ({
              label: a.name,
              href: `/shop?stage=${src.stage}&age_group=${encodeURIComponent(
                a.slug
              )}`,
            }));

          const quick = [
            { title: "Shop for", links: GENDER_QUICK(src.stage) },
          ];

          if (ageLinks.length) {
            quick.push({ title: "Shop by age", links: ageLinks });
          }

          put(link.label, { nodes, quick });
        })
        .catch(() => {});
    });

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);

    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (!isLoggedIn()) return;

    auth.me().then(setUser).catch(() => {});

    api
      .wishlist()
      .then((r) => {
        const items = Array.isArray(r)
          ? r
          : (r as { results: Wishlist[] }).results;

        setWishlistCount(items.length);
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (
        searchBoxRef.current &&
        !searchBoxRef.current.contains(e.target as Node)
      ) {
        setSearchOpen(false);
        setSearchQuery("");
      }
    }

    function handleKey(e: KeyboardEvent) {
      if (e.key === "Escape") {
        setSearchOpen(false);
        setSearchQuery("");
      }
    }

    document.addEventListener("mousedown", handleClick);
    document.addEventListener("keydown", handleKey);

    return () => {
      document.removeEventListener("mousedown", handleClick);
      document.removeEventListener("keydown", handleKey);
    };
  }, []);

  useEffect(() => {
    const q = searchQuery.trim();
    let cancelled = false;

    if (!q) {
      const handle = setTimeout(() => {
        if (!cancelled) {
          setSuggestions([]);
          setSearching(false);
        }
      }, 0);

      return () => {
        cancelled = true;
        clearTimeout(handle);
      };
    }

    const handle = setTimeout(() => {
      if (cancelled) return;

      setSearching(true);

      api
        .smartSearch(q)
        .then((r) => {
          if (cancelled) return;
          setSuggestions((r.results || []).slice(0, 5));
        })
        .catch(() => {
          if (!cancelled) setSuggestions([]);
        })
        .finally(() => {
          if (!cancelled) setSearching(false);
        });
    }, 200);

    return () => {
      cancelled = true;
      clearTimeout(handle);
    };
  }, [searchQuery]);

  function handleSearchSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    router.push(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    setSearchOpen(false);
    setSearchQuery("");
  }

  function goToSuggestion(product: ProductListItem) {
    setSearchOpen(false);
    setSearchQuery("");
    router.push(`/product/${product.slug}`);
  }

  function dismissAnnouncement() {
    setShowAnnouncement(false);

    if (typeof window !== "undefined") {
      try {
        sessionStorage.setItem(ANNOUNCEMENT_KEY, "1");
      } catch {
        /* ignore storage errors */
      }
    }
  }

  return (
    <>
      {/* App banner (Zara-style). Lives in normal flow ABOVE the pinned header, so it scrolls
          away with the page like Zara's and the header alone stays on screen.
          Gated on `mounted` to avoid a hydration mismatch. */}
      {mounted && showAnnouncement && (
        <div className="relative z-40 bg-white">
          <div className="border-b border-stone-300">
            <div className="max-w-[1600px] mx-auto flex items-center gap-3 px-3 py-2 sm:px-5">
              <button
                aria-label="Dismiss announcement"
                onClick={dismissAnnouncement}
                className="shrink-0 p-1.5 -ml-1 text-stone-900 hover:text-stone-500 transition"
              >
                <X className="w-5 h-5" strokeWidth={1.5} />
              </button>

              <div className="shrink-0 flex h-11 w-11 items-center justify-center rounded-[6px] border border-stone-200 bg-white p-1">
                <img src="/Asset_2_1.svg" alt="Larktribe" className="w-full h-auto object-contain" />
              </div>

              <div className="min-w-0 flex-1 text-[12px] sm:text-[13px] leading-snug text-stone-900">
                <p className="font-medium">A better experience.</p>
                <p className="text-stone-600">Discover it in the app.</p>
              </div>

              <Link
                href={APP_URL}
                className="shrink-0 bg-black px-4 py-2.5 sm:px-6 text-[11px] sm:text-xs uppercase tracking-wide text-white hover:bg-stone-800 transition"
              >
                Open app
              </Link>
            </div>
          </div>

          {/* Our promo copy, unchanged, under the app banner */}
          <p className="bg-[#F6C7A8] text-stone-900 text-center text-[11px] leading-snug tracking-[0.02em] px-4 py-1.5">
            Free delivery on orders over KES 5,000 <span className="mx-1">·</span> Get 5% off your first order when you{" "}
            <Link
              href="/register"
              className="font-semibold underline underline-offset-2 hover:text-stone-600 transition"
            >
              sign up
            </Link>
          </p>
        </div>
      )}

      <header ref={headerRef} className="sticky top-0 left-0 right-0 z-40 border-b border-stone-200 bg-white/95 backdrop-blur transition-colors duration-200">
        <div className="container-shellheader">
          <div className="relative flex items-center h-16 lg:h-20">
            {/* Mobile hamburger */}
            <button
              aria-label="Menu"
              onClick={() => setMobileOpen(true)}
              className="p-2 -ml-2 lg:hidden"
            >
              <Menu className="w-5 h-5" strokeWidth={1.5} />
            </button>

            {/* Desktop navigation */}
            <nav className="hidden lg:flex items-center gap-8 flex-1">
              {NAV_LINKS.map((link) => {
                const menu = menus[link.label];

                if (menu && menu.nodes.length > 0) {
                  return (
                    <div
                      key={link.label}
                      className="group py-6 -my-6"
                      onMouseLeave={() => setClosedMenu(null)}
                    >
                      <Link
                        href={link.href}
                        onClick={() => setClosedMenu(link.label)}
                        className="flex items-center gap-1 text-[11px] tracking-[0.12em] uppercase font-medium text-stone-600 hover:text-black transition border-b border-transparent group-hover:border-black pb-0.5"
                      >
                        {link.label}

                        <ChevronDown
                          className="w-3 h-3 opacity-60 group-hover:opacity-100 group-hover:rotate-180 transition"
                          strokeWidth={1.5}
                        />
                      </Link>

                      {/* Full-width hover background; padded inner content */}
                      <div
                        className={`absolute left-1/2 top-full w-screen -translate-x-1/2 bg-white border-t border-stone-100 shadow-[0_20px_40px_-20px_rgba(0,0,0,0.18)] opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-150 z-50 ${
                          closedMenu === link.label ? "hidden" : ""
                        }`}
                      >
                        <div className="px-5 sm:px-8 lg:px-12 xl:px-16">
                          <MegaPanel
                            label={link.label}
                            href={link.href}
                            data={menu}
                            onNavigate={() => setClosedMenu(link.label)}
                          />
                        </div>
                      </div>
                    </div>
                  );
                }

                return (
                  <Link
                    key={link.label}
                    href={link.href}
                    className="text-[11px] tracking-[0.12em] uppercase font-medium text-stone-600 hover:text-black transition border-b border-transparent hover:border-black pb-0.5"
                  >
                    {link.label}
                  </Link>
                );
              })}
            </nav>

            {/* Centered logo */}
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
              <Link
                href="/"
                className="flex flex-col items-center"
              >
                <img
                  src="/Asset_2_1.svg"
                  alt="Larktribe — Curated Kids & Baby Fashion"
                  className="h-4 lg:h-4 w-auto object-contain"
                />
              </Link>
            </div>

            {/* Right utilities */}
            <div className="ml-auto flex items-center gap-1 sm:gap-3">
              <button
                onClick={() => setSearchOpen(true)}
                className="hidden lg:block text-[11px] tracking-[0.12em] uppercase font-medium text-stone-600 hover:text-black transition px-2 py-2"
              >
                Search
              </button>

              <button
                onClick={() => setSearchOpen(true)}
                className="lg:hidden p-2"
              >
                <Search className="w-5 h-5" strokeWidth={1.5} />
              </button>

              {/* Account dropdown */}
              <div className="hidden sm:block group/account relative py-5 -my-5">
                {user ? (
                  <button aria-label="Open account menu" className="flex items-center gap-2 rounded-full px-2 py-1.5 text-stone-600 transition hover:bg-stone-100 hover:text-black focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-stone-400">
                    {user.profile_picture_url ? (
                      <img
                        src={user.profile_picture_url}
                        alt=""
                        className="w-8 h-8 rounded-full object-cover ring-1 ring-stone-200"
                      />
                    ) : (
                      <span className="w-8 h-8 rounded-full bg-stone-100 flex items-center justify-center">
                        <User2
                          className="w-3.5 h-3.5 text-black [-webkit-text-stroke-width:1.5px] [-webkit-text-stroke-color:white]"
                          strokeWidth={1.5}
                        />
                      </span>
                    )}
                    <ChevronDown className="h-3.5 w-3.5 text-stone-400 transition-transform duration-200 group-hover/account:rotate-180" />
                  </button>
                ) : (
                  <button aria-label="Open account menu" className="flex items-center gap-2 rounded-full px-2 py-1.5 text-stone-600 transition hover:bg-stone-100 hover:text-black focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-stone-400">
                    <span className="hidden xl:inline text-[11px] tracking-[0.12em] uppercase">Account</span><ChevronDown className="hidden xl:block h-3.5 w-3.5 text-stone-400 transition-transform duration-200 group-hover/account:rotate-180" />
                    <span className="w-8 h-8 rounded-full bg-stone-100 text-stone-800 flex items-center justify-center">
                      <User2
                        className="w-3.5 h-3.5"
                        strokeWidth={1.5}
                      />
                    </span>
                  </button>
                )}

                <div className="absolute top-full right-0 pt-2.5 opacity-0 invisible translate-y-1 group-hover/account:opacity-100 group-hover/account:visible group-hover/account:translate-y-0 group-focus-within/account:opacity-100 group-focus-within/account:visible group-focus-within/account:translate-y-0 transition-all duration-150 z-40">
                  <div className="w-56 overflow-hidden rounded-md bg-white border border-stone-200 shadow-[0_16px_40px_-18px_rgba(0,0,0,0.28)] text-[13px]">
                    {user ? (
                      <>
                        <div className="px-4 py-3.5 border-b border-stone-100 bg-stone-50/70">
                          <p className="text-[10px] uppercase tracking-[0.12em] text-stone-400">
                            Signed in as
                          </p>
                          <p className="font-medium truncate">
                            {user.first_name || user.username}
                          </p>
                        </div>

                        <Link
                          href="/account"
                          className="block px-4 py-2.5 text-stone-700 hover:bg-stone-50 hover:text-black transition"
                        >
                          Profile
                        </Link>
                        <Link
                          href="/account/orders"
                          className="block px-4 py-2.5 hover:bg-stone-50 transition"
                        >
                          Orders
                        </Link>
                        <Link
                          href="/account/wishlist"
                          className="block px-4 py-2.5 hover:bg-stone-50 transition"
                        >
                          Wishlist
                        </Link>

                        <button
                          onClick={() => {
                            auth.logout();
                            router.push("/");
                          }}
                          className="block w-full text-left px-4 py-3 text-stone-500 hover:text-black hover:bg-stone-50 transition border-t border-stone-100"
                        >
                          Sign Out
                        </button>
                      </>
                    ) : (
                      <>
                        <Link
                          href="/login"
                          className="block px-4 py-2.5 hover:bg-stone-50 transition"
                        >
                          Sign In
                        </Link>
                        <Link
                          href="/register"
                          className="block px-4 py-2.5 hover:bg-stone-50 transition"
                        >
                          Register
                        </Link>
                        <Link
                          href="/orders"
                          className="block px-4 py-2.5 hover:bg-stone-50 transition border-t border-stone-100"
                        >
                          Track Order
                        </Link>
                      </>
                    )}
                  </div>
                </div>
              </div>

              {/* Wishlist count badge — gated on `mounted` */}
              <Link
                href="/account/wishlist"
                aria-label={mounted && wishlistCount > 0 ? `Wishlist, ${wishlistCount} saved items` : "Wishlist"}
                className="p-2 relative hover:text-black transition"
              >
                <Heart className="w-5 h-5" strokeWidth={1.4} />
                {mounted && wishlistCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 min-w-[17px] h-[17px] px-1 rounded-full bg-[#FFE400] text-stone-900 text-[10px] font-bold leading-[17px] text-center ring-1 ring-white">
                    {wishlistCount > 99 ? "99+" : wishlistCount}
                  </span>
                )}
              </Link>

              {/* Cart count badge — gated on `mounted` */}
              <button
                onClick={openDrawer}
                aria-label={mounted && itemCount > 0 ? `Shopping bag, ${itemCount} items` : "Shopping bag"}
                className="p-2 relative hover:text-black transition"
              >
                <ShoppingBag className="w-5 h-5" strokeWidth={1.4} />
                {mounted && itemCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 min-w-[17px] h-[17px] px-1 rounded-full bg-[#FFE400] text-stone-900 text-[10px] font-bold leading-[17px] text-center ring-1 ring-white">
                    {itemCount > 99 ? "99+" : itemCount}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Search overlay */}
      {searchOpen && (
        <div className="fixed inset-0 z-[100]">
          <div
            ref={searchBoxRef}
            className="absolute left-1/2 -translate-x-1/2 top-16 lg:top-20 w-full max-w-2xl bg-white border-b border-stone-200 shadow-xl"
          >
            <form
              onSubmit={handleSearchSubmit}
              className="flex items-center gap-3 h-14 px-5 border-b border-stone-100"
            >
              <Search
                className="w-4 h-4 text-stone-400"
                strokeWidth={1.5}
              />
              <input
                autoFocus
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 bg-transparent text-sm outline-none placeholder:text-stone-400"
                placeholder="Search products, categories..."
              />
              <button
                type="button"
                onClick={() => {
                  setSearchOpen(false);
                  setSearchQuery("");
                }}
              >
                <X className="w-4 h-4 text-stone-400 hover:text-black" />
              </button>
            </form>

            <div className="max-h-[70vh] overflow-y-auto p-5">
              {searchQuery.trim() ? (
                searching ? (
                  <p className="text-xs text-stone-400 py-4">Searching…</p>
                ) : suggestions.length === 0 ? (
                  <p className="text-xs text-stone-400 py-4">No results.</p>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    {suggestions.map((p) => (
                      <button
                        key={p.id}
                        onClick={() => goToSuggestion(p)}
                        className="text-left group"
                      >
                        <div className="aspect-[3/4] bg-stone-50 overflow-hidden mb-2">
                          {p.image ? (
                            <img
                              src={mediaUrl(p.image)}
                              alt={p.name}
                              className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                            />
                          ) : (
                            <div className="w-full h-full bg-stone-100" />
                          )}
                        </div>
                        <p className="text-[12px] text-stone-800 line-clamp-2">
                          {p.name}
                        </p>
                        <p className="text-[12px] text-stone-500 mt-0.5">
                          KES {parseFloat(p.price).toLocaleString("en-KE")}
                        </p>
                      </button>
                    ))}
                  </div>
                )
              ) : (
                <p className="text-2xl text-stone-400">Type to search…</p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-black/30"
            onClick={() => setMobileOpen(false)}
          />

          <div className="absolute inset-y-0 left-0 w-[85vw] max-w-sm bg-white flex flex-col">
            <div className="flex items-center justify-between p-1 pl-5 border-stone-200">
              <img
                src="/Asset_2_1.svg"
                alt="Larktribe"
                className="h-8 w-auto object-contain pl-20"
              />
              <button onClick={() => setMobileOpen(false)}>
                <X className="w-8 h-8" strokeWidth={2.5} />
              </button>
            </div>

            <nav className="flex-1 overflow-y-auto py-2">
              {NAV_LINKS.map((link) => {
                const menu = menus[link.label];

                if (menu && menu.nodes.length > 0) {
                  const open = mobileExpanded === link.label;

                  return (
                    <div key={link.label}>
                      <button
                        onClick={() =>
                          setMobileExpanded(open ? null : link.label)
                        }
                        className="w-full flex items-center justify-between px-5 py-3.5 text-sm uppercase tracking-wide border-b border-stone-50"
                      >
                        <span>{link.label}</span>
                        <ChevronDown
                          className={`w-4 h-4 transition ${
                            open ? "rotate-180" : ""
                          }`}
                        />
                      </button>

                      {open && (
                        <MobileMenuBody
                          data={menu}
                          href={link.href}
                          label={link.label}
                          onNavigate={() => setMobileOpen(false)}
                        />
                      )}
                    </div>
                  );
                }

                return (
                  <Link
                    key={link.label}
                    href={link.href}
                    onClick={() => setMobileOpen(false)}
                    className="block px-5 py-3.5 text-sm uppercase tracking-wide border-b border-stone-50"
                  >
                    {link.label}
                  </Link>
                );
              })}
            </nav>

            <div className="border-t border-stone-200 p-5 space-y-3 text-sm">
              {user ? (
                <Link
                  href="/account"
                  onClick={() => setMobileOpen(false)}
                  className="block font-medium"
                >
                  {user.first_name || user.username} — Account
                </Link>
              ) : (
                <div className="flex gap-3">
                  <Link
                    href="/login"
                    onClick={() => setMobileOpen(false)}
                    className="font-medium"
                  >
                    Sign In
                  </Link>
                  <span className="text-stone-300">/</span>
                  <Link
                    href="/register"
                    onClick={() => setMobileOpen(false)}
                    className="font-medium"
                  >
                    Register
                  </Link>
                </div>
              )}

              <Link
                href="/account/wishlist"
                onClick={() => setMobileOpen(false)}
                className="block text-stone-500"
              >
                Wishlist
              </Link>
            </div>
          </div>
        </div>
      )}
    </>
  );
}