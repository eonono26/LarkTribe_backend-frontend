'use client';

import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import type { Department, DepartmentMedia } from '@/lib/types';

interface DepartmentCardProps {
  department: Department;
  color: string;
  label: string;
}

export default function DepartmentCard({ department, color, label }: DepartmentCardProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isHovering, setIsHovering] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // Get all media (images and videos)
  const allMedia = [...(department.images || []), ...(department.videos || [])];
  const hasMultipleMedia = allMedia.length > 1;
  const currentMedia = allMedia[currentIndex] || null;
  const isVideo = currentMedia?.media_type === 'video';

  // Handle auto-slide
  useEffect(() => {
    // Clear interval if not hovering, or if it's a video
    if (!isHovering || isVideo) {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
      return;
    }

    // Only auto-slide for images when hovering
    if (isHovering && hasMultipleMedia && !isVideo) {
      intervalRef.current = setInterval(() => {
        setCurrentIndex((prev) => (prev + 1) % allMedia.length);
      }, 2000);
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, [isHovering, hasMultipleMedia, allMedia.length, isVideo]);

  // Handle video playback
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !isVideo) return;

    if (isHovering) {
      video.play().catch(() => {});
    } else {
      video.pause();
      video.currentTime = 0;
    }
  }, [isHovering, isVideo]);

  // Handle video end - move to next media
  const handleVideoEnd = () => {
    if (hasMultipleMedia) {
      setCurrentIndex((prev) => (prev + 1) % allMedia.length);
    }
  };

  // Handle manual navigation
  const goToNext = () => {
    setCurrentIndex((prev) => (prev + 1) % allMedia.length);
  };

  const goToPrevious = () => {
    setCurrentIndex((prev) => (prev - 1 + allMedia.length) % allMedia.length);
  };

  // Reset index when hover ends - using event handler instead of effect
  const handleMouseLeave = () => {
    setIsHovering(false);
    // Reset to first item when leaving, but only if not currently on a video
    if (!isVideo) {
      setCurrentIndex(0);
    }
  };

  const imageUrl = currentMedia?.file_url || null;

  return (
    <Link
      href={`/category/${department.slug}`}
      className="group bg-white border border-[var(--color-line)] rounded-lg overflow-hidden hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={handleMouseLeave}
    >
      <div className="relative h-48 w-full bg-gray-100 overflow-hidden">
        {imageUrl ? (
          <>
            {isVideo ? (
              <video
                ref={videoRef}
                src={imageUrl}
                className="w-full h-full object-cover"
                muted
                playsInline
                onEnded={handleVideoEnd}
              />
            ) : (
              <Image
                src={imageUrl}
                alt={currentMedia?.alt_text || label}
                fill
                className={`
                  object-cover transition-transform duration-700
                  ${isHovering ? 'scale-110' : 'scale-100'}
                `}
                sizes="(max-width: 768px) 50vw, 20vw"
                priority
              />
            )}

            {/* Progress indicators for multiple media */}
            {hasMultipleMedia && (
              <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1.5">
                {allMedia.map((_, idx) => (
                  <div
                    key={idx}
                    className={`
                      h-1 rounded-full transition-all duration-300
                      ${idx === currentIndex ? 'w-5 bg-white' : 'w-1.5 bg-white/50'}
                    `}
                  />
                ))}
              </div>
            )}

            {/* Navigation arrows for multiple media */}
            {hasMultipleMedia && isHovering && (
              <>
                <button
                  onClick={(e) => {
                    e.preventDefault();
                    goToPrevious();
                  }}
                  className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white rounded-full p-1.5 transition-all duration-200"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                  </svg>
                </button>
                <button
                  onClick={(e) => {
                    e.preventDefault();
                    goToNext();
                  }}
                  className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white rounded-full p-1.5 transition-all duration-200"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </button>
              </>
            )}

            {/* Play button overlay for video */}
            {isVideo && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="bg-black/50 rounded-full p-4 backdrop-blur-sm">
                  <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M8 5v14l11-7z" />
                  </svg>
                </div>
              </div>
            )}
          </>
        ) : (
          <div 
            className="w-full h-full flex items-center justify-center"
            style={{ background: color + '20' }}
          >
            <div 
              className="h-20 w-20 rounded-full flex items-center justify-center"
              style={{ background: color }}
            >
              <span className="text-3xl text-white font-bold">
                {label.charAt(0)}
              </span>
            </div>
          </div>
        )}

        {/* Overlay gradient for better text readability */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />

        {/* Department name and info overlay */}
        <div className="absolute bottom-0 left-0 right-0 p-4 pointer-events-none">
          <div className="flex items-center justify-between">
            <span className="text-base font-semibold text-white drop-shadow-md">
              {label}
            </span>
          </div>
        </div>
      </div>
    </Link>
  );
}